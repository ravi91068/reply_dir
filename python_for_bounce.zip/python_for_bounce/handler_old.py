import pybase64

print(pybase64.b64encode(b'test_send_ip', altchars='_:'))
