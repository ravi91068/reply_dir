import json
#import pymysql
import eml_parser
from datetime import datetime
import email
import bs4
import pybase64
import re
import bs4
import sys
import os
import base64
import requests


#rds_host  = "database-1.c2rgj64hihag.us-east-2.rds.amazonaws.com"
name = "admin"
password = "Ravi91068"
db_name = "auftera-crm"

#conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)


rds_host="database-1.c49q8mkrmbxs.us-east-2.rds.amazonaws.com"
name="admin"
password="Ravi91068"
db_name="list_contacts"

list_conn = pymysql.connect(host=rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)




def json_serial(obj):
  if isinstance(obj, datetime.datetime):
      serial = obj.isoformat()
      return serial




def get_body_part_of_email(raw_email):
    b=email.message_from_string(raw_email.decode())


    body = ""
    ep = eml_parser.EmlParser()



    for part in b.walk():


        ctype = part.get_content_type()
        cdispo = str(part.get('Content-Disposition'))




        body = part.get_payload(decode=True)




    return body

def get_body_of_ret_email(raw_email,key):

    ret_body=""
    flg=0;
    for part in raw_email['body']:
        if key in part['content_header']:
            if(flg==0):
                ret_body+=part['content_header'][key][0]
                flg=1;

    #ret_body=raw_email['body']['content_header'][key][0]

    return ret_body

def check_best_flg_for_status(arr):
    min_val=0;
    name_of_fnd="";
    for val in arr:
        if(min_val<arr[val]):
            min_val=arr[val]
            name_of_fnd=val;

    if(min_val==0):
        name_of_fnd="not_exist"
    print(name_of_fnd)
    if(name_of_fnd=="not_exist"):
        return 4;
    elif(name_of_fnd=="tm_out"):
        return 3;
    elif(name_of_fnd=="spam"):
        return 2;


def get_type_of_bounce(body):
    flg_spam=1;
    #print(body)
    body=body.lower();
    result_of_good={"not_exist":0,"spam":0,"tm_out":0}

    array_for_hard_bounce={"not_exist":["x-postfix","550","5.5.0","553","5.1.2","5.1.1","5.2.1","552","421","4.7.0","4.3.2","4.7.1","451","4.7.1","554","5.2.0","5.2.2 ","501","5.1.3"],"tm_out":["450","4.7.3","4.2.1","451","4.3.0","4.3.2","4.4.0","4.7.0","452","4.2.2","552","5.2.2","5.2.3","5.7.0","4.2.0","4.1.1","4.3.1"],"spam":["550","551","5.2.2","421","5.7.1","4.7.0","4.7.28","5.7.26","552","5.1.1","554","451","4.7.6","5.4.1","5.2.122","5.7.28","spam","protect","reverse"]}
    for tp in array_for_hard_bounce:
        for find_check in array_for_hard_bounce[tp]:
            fnd_str_char=body.find(find_check);
            str_is_char_flg=0;

            if(find_check.isalpha()):
                str_is_char_flg=1;
            print(fnd_str_char>0 and (((body[fnd_str_char-1]==" " or (body[fnd_str_char-1]==";" or body[fnd_str_char-1]=="-") ) and (body[fnd_str_char+1]==" " or (body[fnd_str_char+1]=="-" or body[fnd_str_char+1]=="."))) or str_is_char_flg==1))


            if(fnd_str_char>0 and (((body[fnd_str_char-1]==" " or (body[fnd_str_char-1]==";" or body[fnd_str_char-1]=="-") ) and (body[fnd_str_char+1]==" " or (body[fnd_str_char+1]=="-" or body[fnd_str_char+1]=="."))) or str_is_char_flg==1)):

                print(find_check)


                result_of_good[tp]+=1
    return (check_best_flg_for_status(result_of_good))








def final_list_name_from_low_name(dir_name):

    dict_for_name={"0_10k_big":"0_10K_big","10_20k_big":"10_20K_big","20k_30k_big":"20K_30K_big","30k_40k_big":"30K_40K_big","40k_big":"40K_Big"}
    return dict_for_name[dir_name]

def getCampDetFromUrl(to_email_arch,tp_sub_stat):
    print(tp_sub_stat)


    split_arr=to_email_arch[0].split('@')[0].split("-");
    create_list_name=split_arr[0]+"^"+pybase64.b64encode(str.encode(split_arr[1])).decode();
    print(create_list_name)
    con_id=split_arr[2]




#    list_conn_curs = list_conn.cursor()


#    update_query="update `"+create_list_name+"` set `substatus`='"+str(tp_sub_stat)+"' where con_id='"+con_id+"'"
#    print(update_query)
    #print(update_query)
#    list_conn_curs.execute(update_query)
#    list_conn.commit()






def lambda_handler():
    #data_file=file_name;


    # Get the object from the event and show its content type




    f = open("../test/test.eml", "rb");
    email_body=f.read();





    ep = eml_parser.EmlParser()
    parsed_eml = ep.decode_email_bytes(email_body)









    to=parsed_eml['header']['to'][0]
    email_from=parsed_eml['header']['from']


    #print(parsed_eml['header']['in-reply-to'][0]);

    data_name=email_from.split("-")



    base64_bytes = data_name[2].encode('ascii')
    message_bytes = base64.b64encode(base64_bytes)
    message = message_bytes.decode('ascii')
    tbl_name=data_name[0]+"^"+message;


    con_id=data_name[3]
    tbl_name=data_name[0]+"^"+message;
    field_name=data_name[0]+"^"+data_name[1]

    data_tp_req={"trg_tp":"reply_ml_trg",'field':"add","cmp":field_name,"data":tbl_name}

    url = 'https://automation.mailatmars.com/automation/create/ajaxfile/auta_flow.php'
    myobj = {"jsn_arr":json.dumps(data_tp_req),"con_id":con_id}

    x = requests.post(url, data = myobj)
    mycursor = list_conn.cursor()

    update_query="update `"+tbl_name+"` set `field_name`='100000' where con_id='"+con_id+"'"
    mycursor.execute(update_query)

    list_conn.commit()

































#file_name=sys.argv[1];
lambda_handler();
